import type { Plugin } from '@openclaw/types';
import { loadConfig, type WorldTreeConfig } from './config';
import { registerHooks } from './hooks';
import { registerChannels } from './channels';

const WorldTreePlugin: Plugin<WorldTreeConfig> = {
  name: 'worldtree',
  version: '0.1.0',
  description: 'WorldTree Architecture Adaptation Layer Plugin',
  author: 'OpenClaw Team',
  
  async install(context, userConfig) {
    const config = loadConfig(userConfig);
    
    if (!config.enabled) {
      context.logger.info('WorldTree plugin is disabled, skipping initialization');
      return;
    }
    
    context.logger.info('Initializing WorldTree plugin...');
    
    // Register event hooks
    await registerHooks(context, config);
    
    // Register multi-channel adapters
    await registerChannels(context, config);
    
    context.logger.info('WorldTree plugin initialized successfully');
  },
  
  async uninstall(context) {
    context.logger.info('Uninstalling WorldTree plugin...');
    // Cleanup logic
    context.logger.info('WorldTree plugin uninstalled successfully');
  }
};

export default WorldTreePlugin;
